package com.example.appengine.demos.springboot.services;

import java.util.concurrent.ExecutionException;

public interface FirebaseService {

	void getUserById(String uid) throws InterruptedException, ExecutionException;
	void createUser() throws InterruptedException, ExecutionException;
}
