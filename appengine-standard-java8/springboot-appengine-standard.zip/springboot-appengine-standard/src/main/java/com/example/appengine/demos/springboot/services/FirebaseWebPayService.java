package com.example.appengine.demos.springboot.services;

import com.example.appengine.demos.springboot.model.Billing;
import com.google.api.core.ApiFuture;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.Query;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.cloud.FirestoreClient;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.springframework.util.ResourceUtils;

public class FirebaseWebPayService {

	private static Firestore db = null;

	public FirebaseWebPayService(Firestore db) {
		FirebaseWebPayService.db = db;
	}
	
	public static Firestore initializerFirestore() {
		if(FirebaseWebPayService.db == null) {
			final GoogleCredentials credentials;
			try {
				File file = ResourceUtils.getFile("classpath:webpay-mall-firebase.json");
				final FileInputStream serviceAccount = new FileInputStream(file);
		 	    
		        credentials = GoogleCredentials.fromStream(serviceAccount);
		        System.out.println("Credentials OK");
		    } catch (IOException e) {
		        System.out.println("Error while reading Firebase config file."+ e);
		        throw new IllegalStateException(e);
		    }
		    final FirebaseOptions options = new FirebaseOptions.Builder()
		            .setDatabaseUrl("https://webpay-mall.firebaseio.com")
		            .setCredentials(credentials)
		            .build();
		    FirebaseApp.initializeApp(options);
		    final Firestore firestore = FirestoreClient.getFirestore();
		    return firestore;
		}else {
			return FirebaseWebPayService.db;
		}
		
		
	}
	
	public void saveTokenBilling(String idBilling, String token) throws InterruptedException, ExecutionException{
		// Create a Map to store the data we want to set
		Map<String, Object> docData = new HashMap<>();
		docData.put("idBilling", idBilling);
		docData.put("token", token);
		// Add a new document (asynchronously) in collection "cities" with id "LA"
		ApiFuture<DocumentReference> future = db.collection("billing").add(docData);
		// ...
		// future.get() blocks on response
		System.out.println("Update time : " + future.get().getId());
		
	}
	
	  public Billing findBillingByToken(String token) throws Exception {
		  Billing bill = new Billing();
		    // [START fs_get_doc_as_map]
		  CollectionReference billing = db.collection("billing");
		  Query query = billing.whereEqualTo("token", token);
		// retrieve  query results asynchronously using query.get()
		  ApiFuture<QuerySnapshot> querySnapshot = query.get();

		  for (DocumentSnapshot document : querySnapshot.get().getDocuments()) {
		    System.out.println(document.getId());
		    if (document.exists()) {
		    	bill = document.toObject(Billing.class);
		    	System.out.println("Document data: " + document.getData());
		    	System.out.println("Billing data: " + bill.toString());
		    } else {
		      System.out.println("No such document!");
		    }
		  }
		    // [END fs_get_doc_as_map]
		    return bill;
	  }
}
