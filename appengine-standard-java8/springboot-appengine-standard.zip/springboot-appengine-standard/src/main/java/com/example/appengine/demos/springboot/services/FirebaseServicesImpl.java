package com.example.appengine.demos.springboot.services;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.cloud.FirestoreClient;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
/**
 * Auth snippet for documentation.
 *
 * See:
 * https://firebase.google.com/docs/auth/admin
 */
public class FirebaseServicesImpl {
	private static Firestore db = null;
	FirebaseServicesImpl(Firestore db) {
		FirebaseServicesImpl.db = db;
	    
	  }

  public static Firestore initializeFirestore() {
	  final GoogleCredentials credentials;
	    try {
	    	 final FileInputStream serviceAccount = new FileInputStream("c:/merci-db.json");
	 	    
	        credentials = GoogleCredentials.fromStream(serviceAccount);
	        System.out.println("Credentials OK");
	    } catch (IOException e) {
	        System.out.println("Error while reading Firebase config file."+ e);
	        throw new IllegalStateException(e);
	    }
	    final FirebaseOptions options = new FirebaseOptions.Builder()
	            .setDatabaseUrl("https://merci-app-3c551.firebaseio.com")
	            .setCredentials(credentials)
	            .build();
	    FirebaseApp.initializeApp(options);
	    final Firestore firestore = FirestoreClient.getFirestore();
	    return firestore;
	}
	 
  
  public static Map<String, Object> getCompraById(String idCompra) {
	  DocumentReference docRef = db.collection("compras").document(idCompra);
	  ApiFuture<DocumentSnapshot> future = docRef.get();
	    // ...
	    // future.get() blocks on response
	    DocumentSnapshot document;
		try {
			document = future.get();
			 if (document.exists()) {
			      System.out.println("Document data: " + document.getData());
			    } else {
			      System.out.println("No such document!");
			    }
			    // [END fs_get_doc_as_map]
			    return (document.exists()) ? document.getData() : null;
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return(null);
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return(null);
		}
	   
  }

  public static void updateCompraStatus(String idCompra, Integer status) {
	  Map<String, Object> data = new HashMap<>();
	  data.put("status", status);
	  db.collection("compras").document(idCompra).update(data);
  }

	/*
	 * public static void main(String[] args) throws InterruptedException,
	 * ExecutionException {
	 * 
	 * db = initializeFirestore(); // Smoke test // createUserWithUid(); //
	 * getUserById("some-uid"); // getUserByEmail("user@example.com"); //
	 * getUserByPhoneNumber("+11234567890"); // updateUser("some-uid");
	 * //setCustomUserClaims("some-uid"); // listAllUsers();
	 * getCompraById("6ifc5zg3b0dpL4WG391Q");
	 * 
	 * // deleteUser("some-uid"); // createCustomToken(); //
	 * createCustomTokenWithClaims(); System.out.println("Done!"); }
	 */

}